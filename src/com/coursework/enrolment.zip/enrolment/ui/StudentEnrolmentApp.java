package com.coursework.enrolment.ui;

import com.coursework.enrolment.model.Student;
import com.coursework.enrolment.service.StudentEnrolmentService;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Main Swing UI for the Student Enrolment Program.
 */
public class StudentEnrolmentApp extends JFrame {
    private final StudentEnrolmentService service;

    private JTextField searchField;
    private JTextField nameField;
    private JTextField icNumberField;
    private JTextField emailField;
    private JTextField phoneNumberField;
    private JTextField dateOfBirthField;
    private JComboBox<String> courseComboBox;
    private JTable studentTable;
    private DefaultTableModel tableModel;
    private JPanel detailsPanel;
    private JLabel detailsContentLabel;

    public StudentEnrolmentApp() {
        this.service = new StudentEnrolmentService();

        setTitle("Student Enrolment Program");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1300, 750);
        setLocationRelativeTo(null);

        buildUI();
        refreshTable(service.getAllStudents());
    }

    private void buildUI() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("Student Enrolment Program");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(20));

        mainPanel.add(createSearchPanel());
        mainPanel.add(Box.createVerticalStrut(15));

        mainPanel.add(createAddStudentPanel());
        mainPanel.add(Box.createVerticalStrut(15));

        detailsPanel = createDetailsPanel();
        detailsPanel.setVisible(false);
        mainPanel.add(detailsPanel);
        mainPanel.add(Box.createVerticalStrut(15));

        mainPanel.add(createTablePanel());

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        setContentPane(scrollPane);
    }

    private JPanel createSearchPanel() {
        JPanel panel = createSectionPanel("Search & Tools");

        searchField = new JTextField(22);
        JButton searchButton = new JButton("Search");
        JButton clearButton = new JButton("Clear Search / View All");
        JButton reportButton = new JButton("Generate Report");
        JButton reverseButton = new JButton("View Reverse Copy");

        searchButton.addActionListener(e -> handleSearch());
        clearButton.addActionListener(e -> handleViewAll());
        reportButton.addActionListener(e -> handleGenerateReport());
        reverseButton.addActionListener(e -> handleViewReverseCopy());

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row.add(searchField);
        row.add(searchButton);
        row.add(clearButton);
        row.add(reportButton);
        row.add(reverseButton);

        panel.add(row);
        return panel;
    }

    private JPanel createAddStudentPanel() {
        JPanel panel = createSectionPanel("Add New Student");

        nameField = new JTextField(14);
        icNumberField = new JTextField(14);
        emailField = new JTextField(18);
        phoneNumberField = new JTextField(12);
        dateOfBirthField = new JTextField(10);
        courseComboBox = new JComboBox<>(new String[]{
            "Computer Science",
            "Software Engineering",
            "Cybersecurity",
            "Data Science",
            "Business Information Technology"
        });
        courseComboBox.setPreferredSize(new Dimension(220, 28));

        JButton enrolButton = new JButton("Enrol Student");
        enrolButton.addActionListener(e -> handleAddStudent());

        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row1.add(new JLabel("Name:"));
        row1.add(nameField);
        row1.add(new JLabel("IC Number:"));
        row1.add(icNumberField);
        row1.add(new JLabel("Email:"));
        row1.add(emailField);

        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row2.add(new JLabel("Phone:"));
        row2.add(phoneNumberField);
        row2.add(new JLabel("DOB:"));
        row2.add(dateOfBirthField);
        row2.add(new JLabel("Course:"));
        row2.add(courseComboBox);
        row2.add(enrolButton);

        panel.add(row1);
        panel.add(row2);
        return panel;
    }

    private JPanel createDetailsPanel() {
        JPanel panel = createSectionPanel("Selected Student Details");

        detailsContentLabel = new JLabel("No student selected.");
        detailsContentLabel.setVerticalAlignment(SwingConstants.TOP);

        JButton closeButton = new JButton("Close Details");
        closeButton.addActionListener(e -> detailsPanel.setVisible(false));

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPanel.add(detailsContentLabel, BorderLayout.CENTER);
        contentPanel.add(closeButton, BorderLayout.SOUTH);

        panel.add(contentPanel);
        return panel;
    }

    private JPanel createTablePanel() {
        JPanel panel = createSectionPanel("Enrolled Students");

        tableModel = new DefaultTableModel(new Object[]{"ID", "Name", "IC Number", "Email", "Phone", "DOB", "Course"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        studentTable = new JTable(tableModel);
        studentTable.setRowHeight(26);

        JButton viewButton = new JButton("View Selected");
        JButton deleteButton = new JButton("Delete Selected");

        viewButton.addActionListener(e -> handleViewSelectedStudent());
        deleteButton.addActionListener(e -> handleDeleteSelectedStudent());

        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonRow.add(viewButton);
        buttonRow.add(deleteButton);

        panel.add(new JScrollPane(studentTable));
        panel.add(buttonRow);
        return panel;
    }

    private JPanel createSectionPanel(String title) {
        JPanel wrapper = new JPanel();
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        wrapper.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.add(titleLabel);
        wrapper.add(Box.createVerticalStrut(10));

        return wrapper;
    }

    private void handleAddStudent() {
        String name = nameField.getText().trim();
        String icNumber = icNumberField.getText().trim();
        String email = emailField.getText().trim();
        String phoneNumber = phoneNumberField.getText().trim();
        String dateOfBirth = dateOfBirthField.getText().trim();
        String course = (String) courseComboBox.getSelectedItem();

        if (name.isEmpty() || icNumber.isEmpty() || email.isEmpty()
                || phoneNumber.isEmpty() || dateOfBirth.isEmpty()
                || course == null || course.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fill in all fields (Name, IC Number, Email, Phone, DOB, Course).",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean isAdded = service.addStudent(name, icNumber, email, phoneNumber, dateOfBirth, course);

        if (isAdded) {
            clearInputFields();
            JOptionPane.showMessageDialog(this, "Student added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            refreshTable(service.getAllStudents());
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add student. IC number, email, or phone number might already exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleSearch() {
        String keyword = searchField.getText().trim();

        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter name, IC number, email, phone, DOB, or course to search.");
            return;
        }

        Student[] results = service.searchStudents(keyword);

        if (results.length == 0) {
            JOptionPane.showMessageDialog(this, "No matching student found.");
            return;
        }

        refreshTable(results);
    }

    private void handleViewAll() {
        searchField.setText("");
        Student[] students = service.getAllStudents();
        refreshTable(students);

        if (students.length == 0) {
            JOptionPane.showMessageDialog(this, "No student enrolment records available.");
        }
    }

    private void handleViewReverseCopy() {
        Student[] reverseStudents = service.getReverseCopy();
        refreshTable(reverseStudents);

        if (reverseStudents.length == 0) {
            JOptionPane.showMessageDialog(this, "No student enrolment records available.");
        }
    }

    private void handleGenerateReport() {
        String report = service.generateReport();

        JOptionPane.showMessageDialog(this, report, "Report", JOptionPane.INFORMATION_MESSAGE);

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Do you want to save this report as a text file?",
                "Save Report",
                JOptionPane.YES_NO_OPTION
        );

        if (choice == JOptionPane.YES_OPTION) {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Save Report");
            fileChooser.setSelectedFile(new java.io.File("enrolment_report.txt"));

            int userSelection = fileChooser.showSaveDialog(this);

            if (userSelection == JFileChooser.APPROVE_OPTION) {
                java.io.File fileToSave = fileChooser.getSelectedFile();

                try (java.io.FileWriter writer = new java.io.FileWriter(fileToSave)) {
                    writer.write(report);
                    JOptionPane.showMessageDialog(this, "Report saved successfully!");
                } catch (java.io.IOException ex) {
                    JOptionPane.showMessageDialog(this, "Failed to save report.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void handleViewSelectedStudent() {
        int selectedRow = studentTable.getSelectedRow();

        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a student first.");
            return;
        }

        String id = tableModel.getValueAt(selectedRow, 0).toString();
        String name = tableModel.getValueAt(selectedRow, 1).toString();
        String icNumber = tableModel.getValueAt(selectedRow, 2).toString();
        String email = tableModel.getValueAt(selectedRow, 3).toString();
        String phoneNumber = tableModel.getValueAt(selectedRow, 4).toString();
        String dateOfBirth = tableModel.getValueAt(selectedRow, 5).toString();
        String course = tableModel.getValueAt(selectedRow, 6).toString();

        detailsContentLabel.setText("<html>"
                + "<b>ID:</b> " + id + "<br><br>"
                + "<b>Name:</b> " + name + "<br><br>"
                + "<b>IC Number:</b> " + icNumber + "<br><br>"
                + "<b>Email:</b> " + email + "<br><br>"
                + "<b>Phone:</b> " + phoneNumber + "<br><br>"
                + "<b>DOB:</b> " + dateOfBirth + "<br><br>"
                + "<b>Course:</b> " + course
                + "</html>");

        detailsPanel.setVisible(true);
    }

    private void handleDeleteSelectedStudent() {
        int selectedRow = studentTable.getSelectedRow();

        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a student from the table first.");
            return;
        }

        String name = tableModel.getValueAt(selectedRow, 1).toString();
        String email = tableModel.getValueAt(selectedRow, 3).toString();

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete student: " + name + "?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        boolean isDeleted = service.deleteStudent(email);

        if (isDeleted) {
            JOptionPane.showMessageDialog(this, "Student deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            refreshTable(service.getAllStudents());
            detailsPanel.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete student. Record might not exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshTable(Student[] students) {
        tableModel.setRowCount(0);

        for (Student student : students) {
            tableModel.addRow(new Object[]{
                    student.getId(),
                    student.getName(),
                    student.getIcNumber(),
                    student.getEmail(),
                    student.getPhoneNumber(),
                    student.getDateOfBirth(),
                    student.getCourse()
            });
        }
    }

    private void clearInputFields() {
        nameField.setText("");
        icNumberField.setText("");
        emailField.setText("");
        phoneNumberField.setText("");
        dateOfBirthField.setText("");
        courseComboBox.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentEnrolmentApp app = new StudentEnrolmentApp();
            app.setVisible(true);
        });
    }
}
